<template >
    <div class="page-not-found">
        <h2>Trang bị lỗi 404</h2>
    </div>
</template>
<style lang="scss">
    .page-not-found{
        height: 100vh;
        text-align: center;
        padding-top: 100px;
        // background-image: url(@/assets/image/404/canva-purple-and-pink-illustration-error-404-facebook-post-TO_qoLZ6Bzs.jpg);
    }
</style>