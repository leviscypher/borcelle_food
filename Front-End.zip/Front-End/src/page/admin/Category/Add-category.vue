<script lang="ts" setup>
import AddCategory from "@/components/page/admin/Category/Add-category.vue" 
</script>
<template>
  <add-category />
</template>