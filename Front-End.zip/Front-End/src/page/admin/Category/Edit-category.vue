<script lang="ts" setup>
import EditCategory from "@/components/page/admin/Category/Edit-category.vue" 
</script>
<template>
  <edit-category />
</template>