<script lang="ts" setup>
import Category from "@/components/page/admin/Category/index.vue" 
</script>
<template>
  <category />
</template>