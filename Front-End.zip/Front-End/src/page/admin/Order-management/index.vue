<script lang="ts" setup>
import OrderManagement from "@/components/page/admin/Order-management/index.vue"
</script>
<template>
  <order-management />
</template>

