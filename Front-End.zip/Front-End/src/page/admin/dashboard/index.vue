<script lang="ts" setup>
import Dashboard from "@/components/page/admin/Dashboard/index.vue"
</script>
<template>
  <Dashboard />
</template>

