<script lang="ts" setup>
import Salarystatement from "@/components/page/admin/Salary-statement/index.vue"
</script>
<template>
  <Salarystatement />
</template>

<style lang="">
    
</style>