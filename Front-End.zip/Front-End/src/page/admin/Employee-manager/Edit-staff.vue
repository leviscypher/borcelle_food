<script lang="ts" setup>
import EddStaff from "@/components/page/admin/Employee-manager/Edit-new-staff.vue"
</script>
<template>
   <EddStaff/>
</template>
