<script lang="ts" setup>
import AddStaff from "@/components/page/admin/Employee-manager/Add-new-staff.vue"
</script>
<template>
   <AddStaff/>
</template>
