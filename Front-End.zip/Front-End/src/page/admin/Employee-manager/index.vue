<script lang="ts" setup>
import EmployeeManager from "@/components/page/admin/Employee-manager/index.vue"
</script>
<template>
  <employee-manager />
</template>

