<script lang="ts" setup>
import CustomerManagement from "@/components/page/admin/Customer-management/index.vue"
</script>
<template>
  <CustomerManagement />
</template>

