<script lang="ts" setup>
import Internalmanagement from "@/components/page/admin/Internal-management/index.vue"
</script>
<template>
  <Internalmanagement />
</template>