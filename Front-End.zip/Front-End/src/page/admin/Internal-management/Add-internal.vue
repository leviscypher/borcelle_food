<script lang="ts" setup>
import AddInternal from "@/components/page/admin/Internal-management/Add-internal.vue"
</script>
<template>
    <add-internal />
</template>