<script lang="ts" setup>
import ProductManagement from "@/components/page/admin/Product-management/index.vue"
</script>
<template>
  <ProductManagement/>
</template>

<style lang="">
    
</style>