<script lang="ts" setup>
import AddProducts from "@/components/page/admin/Product-management/Add-new-products.vue"
</script>
<template>
   <add-products/>
</template>
