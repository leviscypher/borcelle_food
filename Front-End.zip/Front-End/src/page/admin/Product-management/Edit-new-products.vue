<script lang="ts" setup>
import EditProducts from "@/components/page/admin/Product-management/Edit-new-products.vue"
</script>
<template>
   <edit-products/>
</template>
