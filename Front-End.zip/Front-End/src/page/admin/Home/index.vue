<script lang="ts" setup>
import Home from "@/components/page/admin/Home/index.vue"
</script>
<template>
  <Home />
</template>