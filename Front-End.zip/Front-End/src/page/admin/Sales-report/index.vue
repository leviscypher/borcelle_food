<script lang="ts" setup>
import Salesreport from "@/components/page/admin/Sales-report/index.vue"
</script>
<template>
    <Salesreport />
</template>
