<script lang="ts" setup>
import Login from "@/components/page/admin/Auth/index.vue"
</script>
<template >
    <login />
</template>
