<script lang="ts" setup>
import AccountManagement from "@/components/page/admin/Account-management/index.vue" 
</script>
<template>
  <account-management />
</template>