<script lang="ts" setup>
import AddAccount from "@/components/page/admin/Account-management/Add-account.vue" 
</script>
<template>
  <add-account />
</template>