<script lang="ts" setup>
import EditAccount from "@/components/page/admin/Account-management/Edit-account.vue" 
</script>
<template>
  <edit-account />
</template>