<script lang="ts" setup>
import Cart from "@/components/page/user/Cart/index.vue"
</script>
<template>
  <div>
    <Cart />
  </div>
</template>


<style lang="scss" scoped></style>
