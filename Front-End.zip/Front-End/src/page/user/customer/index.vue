<script lang="ts" setup>
import Customer from '@/components/page/user/customer/customer.vue'
</script>

<template lang="">
  <customer />
</template>
<style lang=""></style>
