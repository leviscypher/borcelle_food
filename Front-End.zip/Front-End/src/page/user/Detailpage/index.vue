<script lang="ts" setup>
import Detailpage from "@/components/page/user/Detailpage/detailpage.vue"
</script>
<template >
  <Detailpage />
</template>
<style lang="">
  
</style>