<script lang="ts" setup>
import Order from "@/components/page/user/Order/index.vue"
</script>
<template>
  <div>
    <order />
  </div>
</template>


<style lang="scss" scoped></style>
