<script lang="ts" setup>
import Home from "@/components/page/user/Home/Home.vue"
</script>
<template>
  <div>
    <Home />
  </div>
</template>


<style lang="scss" scoped>

</style>
