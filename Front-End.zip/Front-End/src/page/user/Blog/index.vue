<script lang="ts" setup>
import Blog from "@/components/page/user/Blog/index.vue"
</script>
<template>
  <div>
    <Blog />
  </div>
</template>


<style lang="scss" scoped>

</style>
