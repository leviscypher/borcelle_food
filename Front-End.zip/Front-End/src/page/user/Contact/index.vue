<script lang="ts" setup>
import Contact from "@/components/page/user/Contact/index.vue"
</script>
<template>
  <div>
    <Contact />
  </div>
</template>


<style lang="scss" scoped>

</style>
