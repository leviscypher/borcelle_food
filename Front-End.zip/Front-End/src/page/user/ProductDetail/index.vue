<script lang="ts" setup>
import ProductDetail from '@/components/page/user/ProductDetail/ProductDetail.vue'
</script>
<template>
  <ProductDetail />
</template>
