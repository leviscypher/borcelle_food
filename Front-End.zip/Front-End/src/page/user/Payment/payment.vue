<script lang="ts" setup>
import Payment from "@/components/page/user/Payment/index.vue"
</script>
<template>
  <Payment />
</template>
