<template>
     <div class="footer pt-[100px] pb-[70px] flex gap-[50px]">
          <div class="footer-introduce flex-1">
               <div class="footer-introduce-logo">
                    <img src="@/assets/logo/logo.png" class="footer-introduce-photo" alt="">
               </div>
               <div class="footer-introduce-describe mb-[20px]">
                    Lorem ipsum dolor sit amet, consectetur elit, sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua.
               </div>
               <div class="footer-introduce-social-network">
                    <ul class="footer-menu-icon flex list-none">
                         <li class="footer-menu-icon-chill">
                              <font-awesome-icon icon="fa-brands fa-facebook" />
                         </li>
                         <li class="footer-menu-icon-chill">
                              <font-awesome-icon icon="fa-brands fa-twitter" />
                         </li>
                         <li class="footer-menu-icon-chill">
                              <font-awesome-icon icon="fa-brands fa-instagram" />
                         </li>
                         <li class="footer-menu-icon-chill">
                              <font-awesome-icon icon="fa-brands fa-youtube" />
                         </li>
                    </ul>
               </div>
          </div>
          <div class="footer-services flex-1">
               <h2 class="footer-title">Services</h2>
               <ul class="footer-menu list-none">
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Support</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Career</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Chefs</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Testimonials</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Privacy & Policy</span>
                    </li>
               </ul>
          </div>
          <div class="footer-quick-links flex-1">
               <h2 class="footer-title">Quick Link</h2>
               <ul class="footer-menu list-none">
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Services</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Food Collection</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Online Order</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Blog</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-angle-right" />
                         </span>
                         <span class="footer-text">Contcat</span>
                    </li>
               </ul>
          </div>
          <div class="footer-contact-us flex-1">
               <h2 class="footer-title">Contact Us</h2>
               <ul class="footer-menu list-none">
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-phone" />
                         </span>
                         <span class="footer-text">+1 1234 56 789</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-phone" />
                         </span>
                         <span class="footer-text">+5 1434 56 768</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-message" />
                         </span>
                         <span class="footer-text">info@restant.com</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-message" />
                         </span>
                         <span class="footer-text">hello@restant.com</span>
                    </li>
                    <li class="footer-chill">
                         <span class="footer-icon pr-3">
                              <font-awesome-icon icon="fa-solid fa-location-dot" />
                         </span>
                         <span class="footer-text">Br1. 28/A Street, New York, USA</span>
                    </li>
               </ul>
          </div>
     </div>
     <div class="footer rounded-none text-center h-[50px] leading-[50px]">
          Copyright © 2023 Design & Developed
     </div>
</template>
<script lang="ts" setup>

</script>
<style lang="scss" scoped>
@import "@/assets/styles/footer/footer.scss";
</style>