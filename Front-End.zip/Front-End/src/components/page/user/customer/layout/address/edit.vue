<script lang="ts" setup>
import { ref, onMounted, reactive, watch } from 'vue'
import { useAddress } from '@/stores/user'
import { useRoute } from 'vue-router'

const addressData = reactive({
  fullname: '',
  company: '',
  phone: 0,
  delivery_address: '',
  address_type: 0,
  isActive: 0,
  city_id: 2,
  district_id: 0,
  ward_id: 0,
})

const showAlert = ref(false)
const message = ref('')
const alertType = ref('')

const address = useAddress()
const route = useRoute()
const city = ref([])
const district = ref([])
const district_id = ref(0)
const ward = ref([])
const address_id = ref(0)

onMounted(async () => {
  const id = route.params.id
  address.value = id
  await Promise.all([address.fetchAddressEdit(id), address.fetchCity(), address.fetchDistrict(2)])
  addressData.fullname = address.getAddressEdit.fullname
  addressData.company = address.getAddressEdit.company
  addressData.phone = address.getAddressEdit.phone
  addressData.delivery_address = address.getAddressEdit.delivery_address
  addressData.address_type = address.getAddressEdit.address_type
  addressData.isActive = address.getAddressEdit.isActive
  addressData.district_id = address.getAddressEdit.district_id
  addressData.ward_id = address.getAddressEdit.ward_id

 
  city.value = address.getCity
  district.value = address.getDistrict
  await address.fetchWard(addressData.district_id)
  ward.value = address.getWard
})

const changeDistrict = async (event: any) => {
  const id = event.target.value
  await address.fetchWard(id)
  ward.value = address.getWard
}

const checkCity = async (event: any) => {
  if (event.target.value != 2) {
    event.target.value = 2
    showAlert.value = true
    message.value = 'Hiện tại chúng tôi chỉ hỗ trợ khu vực hà nội'
    alertType.value = 'danger'
  }
}

watch(showAlert, (val) => {
  if (val) {
    setTimeout(() => {
      showAlert.value = false
    }, 5000)
  }
})

const updateData = async () => {
  await address.fetchUpdate(address.value, addressData)
  showAlert.value = true
  message.value = 'cập nhật thành công'
  alertType.value = 'success'
}
</script>

<template lang="">
  <div class="my-10 mx-8">
    <h4 class="mb-10">Tạo sổ địa chỉ</h4>
    <div class="w-full bg-[#fff]">
      <div class="w-[600px] py-10 pl-8">
        <form @submit.prevent>
          <div class="form-group flex item-center mb-8">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Họ và Tên:</label
            >
            <div class="flex-1">
              <input
                type="text"
                class="form-control"
                placeholder="nhập tên"
                maxlength="255"
                v-model="addressData.fullname"
              />
            </div>
          </div>

          <div class="form-group flex item-center mb-8">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Tên công ty:</label
            >
            <div class="flex-1">
              <input
                type="text"
                class="form-control"
                placeholder="nhập tên công ty"
                maxlength="255"
              />
            </div>
          </div>

          <div class="form-group flex item-center mb-8">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Số điện thoai:</label
            >
            <div class="flex-1">
              <input
                type="number"
                class="form-control"
                placeholder="nhập số điện thoại"
                maxlength="10"
                v-model="addressData.phone"
              />
            </div>
          </div>

          <div class="form-group flex item-center mb-8">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Tỉnh/Thành phố:</label
            >
            <div class="flex-1">
              <select
                name=""
                class="form-control"
                @change="checkCity"
              >
                <option
                  :value="item.id"
                  v-for="item in city"
                  :key="item.id"
                  :selected="item.id == 2"
                >
                  {{ item.name }}
                </option>
              </select>
            </div>
          </div>

          <div class="form-group flex item-center mb-8">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Quận huyện:</label
            >
            <div class="flex-1">
              <select
                name=""
                class="form-control"
                @change="changeDistrict"
                v-model="addressData.district_id"
              >
                <option
                  :value="item.id"
                  v-for="item in district"
                  :key="item.id"
                  :selected="addressData.district_id"
                >
                  {{ item.name }}
                </option>
              </select>
            </div>
          </div>

          <div class="form-group flex item-center mb-8">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Phường xã:</label
            >
            <div class="flex-1">
              <select
                name=""
                class="form-control"
                v-model="addressData.ward_id"
              >
                <option
                  :value="item.id"
                  v-for="item in ward"
                  :key="item.id"
                  :selected="addressData.ward_id"
                >
                  {{ item.name }}
                </option>
              </select>
            </div>
          </div>

          <div class="form-group flex">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Địa chỉ:</label
            >
            <div class="flex-1">
              <textarea
                class="form-control"
                v-model="addressData.delivery_address"
              ></textarea>
            </div>
          </div>

          <div class="form-group flex items-center">
            <label
              for=""
              class="w-[var(--label-width)] font-light text-[1.4rem] mb-0 flex items-center"
              >Loại địa chỉ:</label
            >
            <div class="flex-1 flex items-center">
              <div class="form-group mb-0 mr-10">
                <input
                  type="radio"
                  value="0"
                  id="home"
                  class="border border-[var(--pale-yellow)]"
                  v-model="addressData.address_type"
                />
                <label
                  for="home"
                  class="ml-4 text-[1.4rem] font-normal"
                  >Nhà riêng - chung cư</label
                >
              </div>

              <div class="form-group mb-0">
                <input
                  type="radio"
                  value="1"
                  id="company"
                  class="border outline-none"
                  v-model="addressData.address_type"
                />
                <label
                  for="company"
                  class="ml-4 text-[1.4rem] font-normal"
                  >Cơ quan - công ty</label
                >
              </div>
            </div>
          </div>

          <div class="form-group ml-[var(--label-width)]">
            <input
              type="checkbox"
              id="default"
              class="border border-[var(--pale-yellow)]"
              v-model="addressData.isActive"
              true-value="1"
              false-value="0"
            />
            <label
              for="default"
              class="ml-4 text-[1.4rem] font-normal"
              >đặt làm mặc định</label
            >
          </div>

          <button
            class="ml-[var(--label-width)] border-none py-[8px] px-[12px] rounded bg-[var(--pale-yellow)]"
            @click="updateData"
          >
            Cập nhật
          </button>
        </form>
      </div>
    </div>
  </div>

  <div v-show="showAlert">
    <div
      class="alert text-[14px] px-[20px] w-auto fixed top-[100px] z-[9999] left-[50%] translate-x-[-50%] text-center"
      :class="alertType ? 'alert-' + alertType : ''"
      role="alert"
    >
      {{ message }}
    </div>
  </div>
</template>

<style lang="" scoped></style>
