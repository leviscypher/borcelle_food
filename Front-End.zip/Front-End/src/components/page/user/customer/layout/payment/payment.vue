<script lang="ts" setup></script>

<template lang="">
  <div class="order my-10 mx-8">
    <h4 class="order-heading mb-5">Đơn hàng của tôi</h4>
    <div class="w-full h-[400px] bg-[#fff]"></div>
  </div>
</template>

<style lang="" scoped></style>
