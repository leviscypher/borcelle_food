<script lang="ts" setup></script>

<template>
  <div class="order-content w-full bg-[#fff] my-10">
    <div class="text-center py-24">
      <img
        class="w-[180px]"
        src="@/assets/image/empty-order.png"
        alt=""
      />
      <nav>chưa có đơn hàng</nav>
    </div>
  </div>
</template>
<style lang="scss"></style>