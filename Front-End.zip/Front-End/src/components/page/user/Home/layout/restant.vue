<template lang="">
  <div class="restant defaul-width-wd grid grid-cols-2 gap-36 mt-80 mx-auto mb-[80px]">
    <div class="restant-img relative">
      <img
        src="@/assets/logo/logo.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant2.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant3.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant4.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant5.png"
        alt=""
      />
    </div>
    <div class="restant-content">
      <h1 class="restant-content-title title title-sm">Borcelle Food là một trong những dịch vụ thực phẩm hợp vệ sinh và đáng tin cậy nhất</h1>
      <p class="restant-content-description description mt-6">
        Borcelle Food là một trong những dịch vụ thực phẩm hợp vệ sinh và đáng tin cậy nhất hiện nay. Với cam kết cung cấp những sản phẩm chất lượng cao và đảm bảo an toàn vệ sinh thực phẩm, Borcelle Food đã trở thành sự lựa chọn hàng đầu của nhiều khách hàng. Với đội ngũ nhân viên chuyên nghiệp và tận tâm, Borcelle Food đảm bảo sự hài lòng của khách hàng trong các món ăn.
      </p>
      <p class="restant-content-description description mt-10">
        cửa hàng bao gồm các địa điểm ăn trưa hoặc ăn uống bình dân và rẻ tiền phục vụ cho những người làm việc gần đó.
      </p>
      <button class="bf-btn-primary mt-12">Biết nhiều hơn</button>
    </div>
  </div>
</template>
<script lang="ts" setup>

</script>
<style lang="scss" scoped>
@import '@/assets/styles/page/home/restant.scss';
</style>
