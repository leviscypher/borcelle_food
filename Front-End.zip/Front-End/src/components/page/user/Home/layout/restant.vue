<template lang="">
  <div class="restant defaul-width-wd grid grid-cols-2 gap-36 mt-80 mx-auto mb-[80px]">
    <div class="restant-img relative">
      <img
        src="@/assets/logo/logo.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant2.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant3.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant4.png"
        alt=""
      />
      <img
        class="restant-animation"
        src="@/assets/image/restant5.png"
        alt=""
      />
    </div>
    <div class="restant-content">
      <h1 class="restant-content-title title title-sm">Restant is One Of The Most Hygienic & Trusted Food Service</h1>
      <p class="restant-content-description description mt-6">
        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
        standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make
        a type specimen book.
      </p>
      <p class="restant-content-description description mt-10">
        Restaurants range from inexpensive and informal lunching or dining places catering to people working nearby.
      </p>
      <button class="bf-btn-primary mt-12">Know more</button>
    </div>
  </div>
</template>
<script>
export default {}
</script>
<style lang="scss" scoped>
@import '@/assets/styles/page/home/restant.scss';
</style>
