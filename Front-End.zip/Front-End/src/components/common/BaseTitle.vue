<template>
    <div class="app-title">
        <ul class="app-breadcrumb breadcrumb m-0">
            <li class="breadcrumb-item">
                <b>
                    <slot></slot>
                </b>
            </li>
        </ul>
    </div>
</template> 
<style lang="scss" scope>
    @import "@/assets/styles/common/base-tilte.scss";
</style>